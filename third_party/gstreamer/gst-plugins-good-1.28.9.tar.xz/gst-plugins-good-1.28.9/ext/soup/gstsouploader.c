/* GStreamer
 * Copyright (C) 2021 Igalia S.L.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "gstsouploader.h"
#include <gmodule.h>

#ifdef HAVE_RTLD_NOLOAD
#include <dlfcn.h>
#endif

#ifdef BUILDING_ADAPTIVEDEMUX2
GST_DEBUG_CATEGORY (gst_adaptivedemux_soup_debug);
#define GST_CAT_DEFAULT gst_adaptivedemux_soup_debug
#else
GST_DEBUG_CATEGORY (gst_soup_debug);
#define GST_CAT_DEFAULT gst_soup_debug
#endif


#ifndef LINK_SOUP

#if !defined(G_OS_UNIX)
#error "dlopen of libsoup is only supported on UNIX"
#endif

#ifdef __APPLE__
#define LIBSOUP_3_SONAME "libsoup-3.0.0.dylib"
#define LIBSOUP_2_SONAME "libsoup-2.4.1.dylib"
#else
#define LIBSOUP_3_SONAME "libsoup-3.0.so.0"
#define LIBSOUP_2_SONAME "libsoup-2.4.so.1"
#endif

#define LOAD_SYMBOL(name) G_STMT_START {                                \
    gpointer sym = NULL;                                                \
    if (!(sym = dlsym (handle, G_STRINGIFY (name)))) {                  \
      GST_ERROR ("Failed to load '%s' from %s, %s", G_STRINGIFY (name), \
          libsoup_sonames[i], dlerror());                               \
      goto error;                                                       \
    }                                                                   \
    G_PASTE (vtable->_, name) = sym;                                    \
  } G_STMT_END;

#define LOAD_VERSIONED_SYMBOL(version, name) G_STMT_START {               \
    gpointer sym = NULL;                                                  \
    if (!(sym = dlsym(handle, G_STRINGIFY(name)))) {                      \
      GST_WARNING ("Failed to load '%s' from %s, %s", G_STRINGIFY(name),  \
                   libsoup_sonames[i], dlerror());                        \
      goto error;                                                         \
    }                                                                     \
    G_PASTE(vtable->_, G_PASTE(name, G_PASTE(_, version))) = sym;         \
  } G_STMT_END;

typedef struct _GstSoupVTable
{
  gboolean loaded;
  guint lib_version;

  /* *INDENT-OFF* */

  /* Symbols present only in libsoup 3. */
#if GLIB_CHECK_VERSION(2, 66, 0)
  GUri *(*_soup_message_get_uri_3)(SoupMessage * msg);
#endif
  SoupLogger *(*_soup_logger_new_3) (SoupLoggerLogLevel level);
  SoupMessageHeaders *(*_soup_message_get_request_headers_3) (SoupMessage * msg);
  SoupMessageHeaders *(*_soup_message_get_response_headers_3) (SoupMessage * msg);
  void (*_soup_message_set_request_body_from_bytes_3) (SoupMessage * msg,
    const char * content_type, GBytes * data);
  const char *(*_soup_message_get_reason_phrase_3) (SoupMessage * msg);
  SoupStatus (*_soup_message_get_status_3) (SoupMessage * msg);

  /* Symbols present only in libsoup 2 */
  SoupLogger *(*_soup_logger_new_2) (SoupLoggerLogLevel, int);
  SoupURI *(*_soup_uri_new_2) (const char *);
  SoupURI *(*_soup_message_get_uri_2) (SoupMessage *);
  char *(*_soup_uri_to_string_2) (SoupURI *, gboolean);
  void (*_soup_message_body_append_2) (SoupMessageBody *, SoupMemoryUse,
    gconstpointer, gsize);
  void (*_soup_uri_free_2) (SoupURI *);
#if defined(LINK_SOUP) && LINK_SOUP == 2
  const gchar *(*_soup_uri_get_scheme_2) (SoupURI *);
  const gchar *(*_soup_uri_get_host_2) (SoupURI *);
  guint (*_soup_uri_get_port_2) (SoupURI *);
#elif !defined(LINK_SOUP)
  /* SoupURI is opaque in the stub, so use gpointer here */
  const gchar *(*_soup_uri_get_scheme_2) (gpointer);
  const gchar *(*_soup_uri_get_host_2) (gpointer);
  guint (*_soup_uri_get_port_2) (gpointer);
#endif
  void (*_soup_session_cancel_message_2) (SoupSession *, SoupMessage *, guint);

  /* Symbols present in libsoup 2 and libsoup 3 */
  GType (*_soup_content_decoder_get_type) (void);
  GType (*_soup_cookie_jar_get_type) (void);
  guint (*_soup_get_major_version) (void);
  guint (*_soup_get_minor_version) (void);
  guint (*_soup_get_micro_version) (void);
  GType (*_soup_logger_log_level_get_type) (void);
  void (*_soup_logger_set_printer) (SoupLogger * logger, SoupLoggerPrinter printer, gpointer user_data,
    GDestroyNotify destroy_notify);
  void (*_soup_message_disable_feature) (SoupMessage * message, GType feature_type);
  void (*_soup_message_headers_append) (SoupMessageHeaders * hdrs, const char * name,
    const char * value);
  void (*_soup_message_headers_foreach) (SoupMessageHeaders * hdrs,
    SoupMessageHeadersForeachFunc callback, gpointer user_data);
  goffset (*_soup_message_headers_get_content_length) (SoupMessageHeaders * hdrs);
  const char *(*_soup_message_headers_get_content_type) (SoupMessageHeaders * hdrs,
    GHashTable ** value);
  gboolean (*_soup_message_headers_get_content_range) (SoupMessageHeaders *hdrs, goffset *start,
    goffset *end, goffset *total_length);
  void (*_soup_message_headers_set_range) (SoupMessageHeaders *hdrs, goffset start, goffset end);
  SoupEncoding (*_soup_message_headers_get_encoding) (SoupMessageHeaders * hdrs);
  const char *(*_soup_message_headers_get_one) (SoupMessageHeaders * hdrs,
    const char * name);
  void (*_soup_message_headers_remove) (SoupMessageHeaders * hdrs, const char * name);
  SoupMessage *(*_soup_message_new) (const char * method, const char * location);
  void (*_soup_message_set_flags) (SoupMessage * msg, SoupMessageFlags flags);
  void (*_soup_session_abort) (SoupSession * session);
  void (*_soup_session_add_feature) (SoupSession * session, SoupSessionFeature * feature);
  void (*_soup_session_add_feature_by_type) (SoupSession * session, GType feature_type);
  SoupSessionFeature *(*_soup_session_get_feature) (SoupSession * session, GType feature_type);
  GType (*_soup_session_get_type) (void);

  void (*_soup_auth_authenticate) (SoupAuth * auth, const char *username,
    const char *password);
  const char *(*_soup_message_get_method_3) (SoupMessage * msg);
  GInputStream *(*_soup_session_send_async_2) (SoupSession * session, SoupMessage * msg,
    GCancellable * cancellable, GAsyncReadyCallback callback, gpointer user_data);
  GInputStream *(*_soup_session_send_async_3) (SoupSession * session, SoupMessage * msg,
    int io_priority, GCancellable * cancellable, GAsyncReadyCallback callback, gpointer user_data);
  GInputStream *(*_soup_session_send_finish) (SoupSession * session,
    GAsyncResult * result, GError ** error);
  GInputStream *(*_soup_session_send) (SoupSession * session, SoupMessage * msg,
    GCancellable * cancellable, GError ** error);
  SoupCookie* (*_soup_cookie_parse) (const char* header, gpointer origin_uri);
  void (*_soup_cookie_jar_add_cookie_full) (SoupCookieJar * jar, SoupCookie * cookie, gpointer uri, gpointer first_party);
  void (*_soup_cookie_free) (SoupCookie * cookie);

  /* *INDENT-ON* */
} GstSoupVTable;

static GstSoupVTable gst_soup_vtable = { 0, };

#define SOUP_NAMES 2

/* Helper functions for accessing SoupURI fields when LINK_SOUP == 2.
 * Used via vtable for runtime loading of libsoup 2. */
#if defined(LINK_SOUP) && LINK_SOUP == 2
static const gchar *
_soup_uri_get_scheme_2 (SoupURI * uri)
{
  return uri->scheme;
}

static const gchar *
_soup_uri_get_host_2 (SoupURI * uri)
{
  return uri->host;
}

static guint
_soup_uri_get_port_2 (SoupURI * uri)
{
  return uri->port;
}
#elif !defined(LINK_SOUP)
/* When SoupURI is opaque (gpointer) in the stub, we define a struct here
 * that matches the libsoup 2 SoupURI layout. */
typedef struct
{
  const gchar *scheme;
  gchar *user;
  gchar *password;
  gchar *host;
  guint port;
} _SoupURI2Fields;

static const gchar *
_soup_uri_get_scheme_2 (gpointer uri)
{
  _SoupURI2Fields *fields = (_SoupURI2Fields *) uri;
  return fields->scheme;
}

static const gchar *
_soup_uri_get_host_2 (gpointer uri)
{
  _SoupURI2Fields *fields = (_SoupURI2Fields *) uri;
  return fields->host;
}

static guint
_soup_uri_get_port_2 (gpointer uri)
{
  _SoupURI2Fields *fields = (_SoupURI2Fields *) uri;
  return fields->port;
}
#endif

gboolean
gst_soup_load_library (void)
{
  GstSoupVTable *vtable;
  const char *libsoup_sonames[SOUP_NAMES + 1] = { 0 };
  gpointer handle = NULL;

  if (gst_soup_vtable.loaded)
    return TRUE;

#ifdef BUILDING_ADAPTIVEDEMUX2
  GST_DEBUG_CATEGORY_INIT (gst_adaptivedemux_soup_debug, "adaptivedemux2-soup",
      0, "adaptivedemux2-soup");
#else
  GST_DEBUG_CATEGORY_INIT (gst_soup_debug, "soup", 0, "soup");
#endif

#ifdef HAVE_RTLD_NOLOAD
  {
    /* In order to avoid causing conflicts we detect if libsoup 2 or 3 is loaded already.
     * If so use that. Otherwise we will try to load our own version to use preferring 3. */

    if ((handle = dlopen (LIBSOUP_3_SONAME, RTLD_NOW | RTLD_NOLOAD))) {
      libsoup_sonames[0] = LIBSOUP_3_SONAME;
      GST_DEBUG ("LibSoup 3 found");
    } else if ((handle = dlopen (LIBSOUP_2_SONAME, RTLD_NOW | RTLD_NOLOAD))) {
      libsoup_sonames[0] = LIBSOUP_2_SONAME;
      GST_DEBUG ("LibSoup 2 found");
    } else {
      GST_DEBUG ("Trying all libsoups");
      libsoup_sonames[0] = LIBSOUP_3_SONAME;
      libsoup_sonames[1] = LIBSOUP_2_SONAME;
    }

    g_clear_pointer (&handle, dlclose);
  }
#else
  libsoup_sonames[0] = LIBSOUP_3_SONAME;
  libsoup_sonames[1] = LIBSOUP_2_SONAME;
#endif /* HAVE_RTLD_NOLOAD */

  vtable = &gst_soup_vtable;

  for (guint i = 0; i < SOUP_NAMES; i++) {
    if (!handle)
      handle = dlopen (libsoup_sonames[i], RTLD_NOW | RTLD_GLOBAL);
    if (handle) {
      GST_DEBUG ("Loaded %s", libsoup_sonames[i]);
      if (g_strstr_len (libsoup_sonames[i], -1, "soup-2")) {
        vtable->lib_version = 2;
        LOAD_VERSIONED_SYMBOL (2, soup_logger_new);
        LOAD_VERSIONED_SYMBOL (2, soup_message_body_append);
        LOAD_VERSIONED_SYMBOL (2, soup_uri_free);
        LOAD_VERSIONED_SYMBOL (2, soup_uri_new);
        LOAD_VERSIONED_SYMBOL (2, soup_uri_to_string);
        LOAD_VERSIONED_SYMBOL (2, soup_message_get_uri);
        LOAD_VERSIONED_SYMBOL (2, soup_session_cancel_message);
        LOAD_VERSIONED_SYMBOL (2, soup_session_send_async);
        vtable->_soup_uri_get_scheme_2 = _soup_uri_get_scheme_2;
        vtable->_soup_uri_get_host_2 = _soup_uri_get_host_2;
        vtable->_soup_uri_get_port_2 = _soup_uri_get_port_2;
      } else {
        vtable->lib_version = 3;
        LOAD_VERSIONED_SYMBOL (3, soup_logger_new);
        LOAD_VERSIONED_SYMBOL (3, soup_message_get_request_headers);
        LOAD_VERSIONED_SYMBOL (3, soup_message_get_response_headers);
        LOAD_VERSIONED_SYMBOL (3, soup_message_set_request_body_from_bytes);
#if GLIB_CHECK_VERSION(2, 66, 0)
        LOAD_VERSIONED_SYMBOL (3, soup_message_get_uri);
#endif
        /* The #else case (old GLib) leaves the symbol NULL. The runtime
         * fallbacks in gst_soup_message_uri_to_string() asserts, as libsoup 3
         * requires GLib >= 2.69.1. */
        LOAD_VERSIONED_SYMBOL (3, soup_message_get_method);
        LOAD_VERSIONED_SYMBOL (3, soup_message_get_reason_phrase);
        LOAD_VERSIONED_SYMBOL (3, soup_message_get_status);
        LOAD_VERSIONED_SYMBOL (3, soup_session_send_async);
      }

      LOAD_SYMBOL (soup_auth_authenticate);
      LOAD_SYMBOL (soup_content_decoder_get_type);
      LOAD_SYMBOL (soup_cookie_jar_get_type);
      LOAD_SYMBOL (soup_get_major_version);
      LOAD_SYMBOL (soup_get_micro_version);
      LOAD_SYMBOL (soup_get_minor_version);
      LOAD_SYMBOL (soup_logger_log_level_get_type);
      LOAD_SYMBOL (soup_logger_set_printer);
      LOAD_SYMBOL (soup_message_disable_feature);
      LOAD_SYMBOL (soup_message_headers_append);
      LOAD_SYMBOL (soup_message_headers_foreach);
      LOAD_SYMBOL (soup_message_headers_get_content_length);
      LOAD_SYMBOL (soup_message_headers_get_content_type);
      LOAD_SYMBOL (soup_message_headers_get_content_range);
      LOAD_SYMBOL (soup_message_headers_set_range);
      LOAD_SYMBOL (soup_message_headers_get_encoding);
      LOAD_SYMBOL (soup_message_headers_get_one);
      LOAD_SYMBOL (soup_message_headers_remove);
      LOAD_SYMBOL (soup_message_new);
      LOAD_SYMBOL (soup_message_set_flags);
      LOAD_SYMBOL (soup_session_abort);
      LOAD_SYMBOL (soup_session_add_feature);
      LOAD_SYMBOL (soup_session_add_feature_by_type);
      LOAD_SYMBOL (soup_session_get_feature);
      LOAD_SYMBOL (soup_session_get_type);
      LOAD_SYMBOL (soup_session_send);
      LOAD_SYMBOL (soup_session_send_finish);
      LOAD_SYMBOL (soup_cookie_parse);
      LOAD_SYMBOL (soup_cookie_jar_add_cookie_full);
      LOAD_SYMBOL (soup_cookie_free);

      vtable->loaded = TRUE;
      goto beach;

    error:
      GST_DEBUG ("Failed to find all libsoup symbols");
      g_clear_pointer (&handle, dlclose);
      continue;
    } else {
      GST_DEBUG ("Module %s not found", libsoup_sonames[i]);
      continue;
    }
  beach:
    break;
  }

  return vtable->loaded;
}

#endif /* !LINK_SOUP */

guint
gst_soup_loader_get_api_version (void)
{
#ifdef LINK_SOUP
  return LINK_SOUP;
#else
  return gst_soup_vtable.lib_version;
#endif
}

SoupSession *
_soup_session_new_with_options (const char *optname1, ...)
{
  SoupSession *session;
  va_list ap;

  va_start (ap, optname1);
  session =
      (SoupSession *) g_object_new_valist (_soup_session_get_type (), optname1,
      ap);
  va_end (ap);
  return session;
}

SoupLogger *
_soup_logger_new (SoupLoggerLogLevel level)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  return soup_logger_new (level, -1);
#elif LINK_SOUP == 3
  return soup_logger_new (level);
#endif
#else
  if (gst_soup_vtable.lib_version == 2) {
    g_assert (gst_soup_vtable._soup_logger_new_2 != NULL);
    return gst_soup_vtable._soup_logger_new_2 (level, -1);
  }
  g_assert (gst_soup_vtable._soup_logger_new_3 != NULL);
  return gst_soup_vtable._soup_logger_new_3 (level);
#endif
}

void
_soup_logger_set_printer (SoupLogger * logger, SoupLoggerPrinter printer,
    gpointer printer_data, GDestroyNotify destroy)
{
#ifdef LINK_SOUP
  soup_logger_set_printer (logger, printer, printer_data, destroy);
#else
  g_assert (gst_soup_vtable._soup_logger_set_printer != NULL);
  gst_soup_vtable._soup_logger_set_printer (logger, printer, printer_data,
      destroy);
#endif
}

void
_soup_session_add_feature (SoupSession * session, SoupSessionFeature * feature)
{
#ifdef LINK_SOUP
  soup_session_add_feature (session, feature);
#else
  g_assert (gst_soup_vtable._soup_session_add_feature != NULL);
  gst_soup_vtable._soup_session_add_feature (session, feature);
#endif
}

GstSoupUri *
gst_soup_uri_new (const char *uri_string)
{
  GstSoupUri *uri = g_new0 (GstSoupUri, 1);
  gboolean parsed;
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  uri->soup_uri = soup_uri_new (uri_string);
  parsed = (uri->soup_uri != NULL);
#else
  uri->uri = g_uri_parse (uri_string, SOUP_HTTP_URI_FLAGS, NULL);
  parsed = (uri->uri != NULL);
#endif
#else
  if (gst_soup_vtable.lib_version == 2) {
    g_assert (gst_soup_vtable._soup_uri_new_2 != NULL);
    uri->soup_uri = gst_soup_vtable._soup_uri_new_2 (uri_string);
    parsed = (uri->soup_uri != NULL);
  } else {
    /* libsoup 3 path */
#if GLIB_CHECK_VERSION(2, 66, 0)
    uri->uri = g_uri_parse (uri_string, SOUP_HTTP_URI_FLAGS, NULL);
    parsed = (uri->uri != NULL);
#else
    /* libsoup 3 requires GLib >= 2.69.1, unreachable with old GLib */
    g_assert_not_reached ();
    parsed = FALSE;
#endif
  }
#endif

  if (!parsed) {
    g_free (uri);
    return NULL;
  }
  return uri;
}

void
gst_soup_uri_free (GstSoupUri * uri)
{
#if (defined(LINK_SOUP) && LINK_SOUP == 3) || (!defined(LINK_SOUP) && GLIB_CHECK_VERSION(2, 66, 0))
  if (uri->uri) {
    g_uri_unref (uri->uri);
  }
#endif

#if defined(LINK_SOUP)
#if LINK_SOUP == 2
  if (uri->soup_uri) {
    soup_uri_free (uri->soup_uri);
  }
#endif
#else /* !LINK_SOUP */
  if (uri->soup_uri) {
    g_assert (gst_soup_vtable._soup_uri_free_2 != NULL);
    gst_soup_vtable._soup_uri_free_2 (uri->soup_uri);
  }
#endif /* LINK_SOUP */
  g_free (uri);
}

char *
gst_soup_uri_to_string (GstSoupUri * uri)
{
  g_return_val_if_fail (uri != NULL, NULL);

#if (defined(LINK_SOUP) && LINK_SOUP == 3) || (!defined(LINK_SOUP) && GLIB_CHECK_VERSION(2, 66, 0))
  if (uri->uri) {
    return g_uri_to_string_partial (uri->uri, G_URI_HIDE_PASSWORD);
  }
#endif

#if defined(LINK_SOUP)
#if LINK_SOUP == 2
  if (uri->soup_uri) {
    return soup_uri_to_string (uri->soup_uri, FALSE);
  }
#endif
#else /* !LINK_SOUP */
  if (uri->soup_uri) {
    g_assert (gst_soup_vtable._soup_uri_to_string_2 != NULL);
    return gst_soup_vtable._soup_uri_to_string_2 (uri->soup_uri, FALSE);
  }
#endif /* LINK_SOUP */

  g_assert_not_reached ();
  return NULL;
}

const gchar *
gst_soup_uri_get_scheme (GstSoupUri * uri)
{
  g_return_val_if_fail (uri != NULL, NULL);

#if (defined(LINK_SOUP) && LINK_SOUP == 3) || (!defined(LINK_SOUP) && GLIB_CHECK_VERSION(2, 66, 0))
  if (uri->uri)
    return g_uri_get_scheme (uri->uri);
#endif

#if defined(LINK_SOUP)
#if LINK_SOUP == 2
  if (uri->soup_uri)
    return uri->soup_uri->scheme;
#endif
#else /* !LINK_SOUP */
  /* dlopen build: libsoup 2 fills soup_uri at runtime */
  if (uri->soup_uri) {
    g_assert (gst_soup_vtable._soup_uri_get_scheme_2 != NULL);
    return gst_soup_vtable._soup_uri_get_scheme_2 ((gpointer) uri->soup_uri);
  }
#endif

  return NULL;
}

const gchar *
gst_soup_uri_get_host (GstSoupUri * uri)
{
  g_return_val_if_fail (uri != NULL, NULL);

#if (defined(LINK_SOUP) && LINK_SOUP == 3) || (!defined(LINK_SOUP) && GLIB_CHECK_VERSION(2, 66, 0))
  if (uri->uri)
    return g_uri_get_host (uri->uri);
#endif

#if defined(LINK_SOUP)
#if LINK_SOUP == 2
  if (uri->soup_uri)
    return uri->soup_uri->host;
#endif
#else /* !LINK_SOUP */
  /* dlopen build: libsoup 2 fills soup_uri at runtime */
  if (uri->soup_uri) {
    g_assert (gst_soup_vtable._soup_uri_get_host_2 != NULL);
    return gst_soup_vtable._soup_uri_get_host_2 ((gpointer) uri->soup_uri);
  }
#endif

  return NULL;
}

guint
gst_soup_uri_get_port (GstSoupUri * uri)
{
  g_return_val_if_fail (uri != NULL, 0);

#if (defined(LINK_SOUP) && LINK_SOUP == 3) || (!defined(LINK_SOUP) && GLIB_CHECK_VERSION(2, 66, 0))
  if (uri->uri) {
    gint port = g_uri_get_port (uri->uri);
    /* g_uri_get_port() returns -1 when no port was specified and
     * G_URI_FLAGS_SCHEME_NORMALIZE was not set (GLib < 2.68).
     * Map to 0 for consistency. */
    if (port == -1)
      return 0;
    return port;
  }
#endif

#if defined(LINK_SOUP)
#if LINK_SOUP == 2
  if (uri->soup_uri)
    return uri->soup_uri->port;
#endif
#else /* !LINK_SOUP */
  /* dlopen build: libsoup 2 fills soup_uri at runtime */
  if (uri->soup_uri) {
    g_assert (gst_soup_vtable._soup_uri_get_port_2 != NULL);
    return gst_soup_vtable._soup_uri_get_port_2 ((gpointer) uri->soup_uri);
  }
#endif

  return 0;
}

char *
gst_soup_message_uri_to_string (SoupMessage * msg)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  SoupURI *uri = NULL;
  uri = soup_message_get_uri (msg);
  return soup_uri_to_string (uri, FALSE);
#elif LINK_SOUP == 3
  GUri *uri = NULL;
  uri = soup_message_get_uri (msg);
  return g_uri_to_string_partial (uri, G_URI_HIDE_PASSWORD);
#endif
#else
  if (gst_soup_vtable.lib_version == 2) {
    SoupURI *uri = NULL;
    g_assert (gst_soup_vtable._soup_message_get_uri_2 != NULL);
    uri = gst_soup_vtable._soup_message_get_uri_2 (msg);
    return gst_soup_vtable._soup_uri_to_string_2 (uri, FALSE);
  } else {
#if GLIB_CHECK_VERSION(2, 66, 0)
    GUri *uri = NULL;
    g_assert (gst_soup_vtable._soup_message_get_uri_3 != NULL);
    uri = gst_soup_vtable._soup_message_get_uri_3 (msg);
    return g_uri_to_string_partial (uri, G_URI_HIDE_PASSWORD);
#endif
  }
#endif
  /*
   * If we reach this, it means the plugin was built for old glib, but somehow
   * we managed to load libsoup3, which requires a very recent glib. As this
   * is a contradiction, we can assert, I guess?
   */
  g_assert_not_reached ();
  return NULL;
}

guint
_soup_get_major_version (void)
{
#ifdef LINK_SOUP
  return soup_get_major_version ();
#else
  g_assert (gst_soup_vtable._soup_get_major_version != NULL);
  return gst_soup_vtable._soup_get_major_version ();
#endif
}

guint
_soup_get_minor_version (void)
{
#ifdef LINK_SOUP
  return soup_get_minor_version ();
#else
  g_assert (gst_soup_vtable._soup_get_minor_version != NULL);
  return gst_soup_vtable._soup_get_minor_version ();
#endif
}

guint
_soup_get_micro_version (void)
{
#ifdef LINK_SOUP
  return soup_get_micro_version ();
#else
  g_assert (gst_soup_vtable._soup_get_micro_version != NULL);
  return gst_soup_vtable._soup_get_micro_version ();
#endif
}

void
_soup_message_set_request_body_from_bytes (SoupMessage * msg,
    const char *content_type, GBytes * bytes)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  gsize size;
  gconstpointer data = g_bytes_get_data (bytes, &size);
  soup_message_body_append (msg->request_body, SOUP_MEMORY_COPY, data, size);
#elif LINK_SOUP == 3
  soup_message_set_request_body_from_bytes (msg, content_type, bytes);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_assert (gst_soup_vtable._soup_message_set_request_body_from_bytes_3 !=
        NULL);
    gst_soup_vtable._soup_message_set_request_body_from_bytes_3 (msg,
        content_type, bytes);
  } else {
    gsize size;
    gconstpointer data = g_bytes_get_data (bytes, &size);
    SoupMessage2 *msg2 = (SoupMessage2 *) msg;
    g_assert (gst_soup_vtable._soup_message_body_append_2 != NULL);
    gst_soup_vtable._soup_message_body_append_2 (msg2->request_body,
        SOUP_MEMORY_COPY, data, size);
  }
#endif
}

GType
_soup_session_get_type (void)
{
#ifdef LINK_SOUP
  return soup_session_get_type ();
#else
  g_assert (gst_soup_vtable._soup_session_get_type != NULL);
  return gst_soup_vtable._soup_session_get_type ();
#endif
}

GType
_soup_logger_log_level_get_type (void)
{
#ifdef LINK_SOUP
  return soup_logger_log_level_get_type ();
#else
  g_assert (gst_soup_vtable._soup_logger_log_level_get_type != NULL);
  return gst_soup_vtable._soup_logger_log_level_get_type ();
#endif
}

GType
_soup_content_decoder_get_type (void)
{
#ifdef LINK_SOUP
  return soup_content_decoder_get_type ();
#else
  g_assert (gst_soup_vtable._soup_content_decoder_get_type != NULL);
  return gst_soup_vtable._soup_content_decoder_get_type ();
#endif
}

GType
_soup_cookie_jar_get_type (void)
{
#ifdef LINK_SOUP
  return soup_cookie_jar_get_type ();
#else
  g_assert (gst_soup_vtable._soup_cookie_jar_get_type != NULL);
  return gst_soup_vtable._soup_cookie_jar_get_type ();
#endif
}

void
_soup_session_abort (SoupSession * session)
{
#ifdef LINK_SOUP
  soup_session_abort (session);
#else
  g_assert (gst_soup_vtable._soup_session_abort != NULL);
  gst_soup_vtable._soup_session_abort (session);
#endif
}

SoupMessage *
_soup_message_new (const char *method, const char *uri_string)
{
#ifdef LINK_SOUP
  return soup_message_new (method, uri_string);
#else
  g_assert (gst_soup_vtable._soup_message_new != NULL);
  return gst_soup_vtable._soup_message_new (method, uri_string);
#endif
}

SoupMessageHeaders *
_soup_message_get_request_headers (SoupMessage * msg)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  return msg->request_headers;
#elif LINK_SOUP == 3
  return soup_message_get_request_headers (msg);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_assert (gst_soup_vtable._soup_message_get_request_headers_3 != NULL);
    return gst_soup_vtable._soup_message_get_request_headers_3 (msg);
  } else {
    SoupMessage2 *msg2 = (SoupMessage2 *) msg;
    return msg2->request_headers;
  }
#endif
}

SoupMessageHeaders *
_soup_message_get_response_headers (SoupMessage * msg)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  return msg->response_headers;
#elif LINK_SOUP == 3
  return soup_message_get_response_headers (msg);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_assert (gst_soup_vtable._soup_message_get_response_headers_3 != NULL);
    return gst_soup_vtable._soup_message_get_response_headers_3 (msg);
  } else {
    SoupMessage2 *msg2 = (SoupMessage2 *) msg;
    return msg2->response_headers;
  }
#endif
}

void
_soup_message_headers_remove (SoupMessageHeaders * hdrs, const char *name)
{
#ifdef LINK_SOUP
  soup_message_headers_remove (hdrs, name);
#else
  g_assert (gst_soup_vtable._soup_message_headers_remove != NULL);
  gst_soup_vtable._soup_message_headers_remove (hdrs, name);
#endif
}

void
_soup_message_headers_append (SoupMessageHeaders * hdrs, const char *name,
    const char *value)
{
#ifdef LINK_SOUP
  soup_message_headers_append (hdrs, name, value);
#else
  g_assert (gst_soup_vtable._soup_message_headers_append != NULL);
  gst_soup_vtable._soup_message_headers_append (hdrs, name, value);
#endif
}

void
_soup_message_set_flags (SoupMessage * msg, SoupMessageFlags flags)
{
#ifdef LINK_SOUP
  soup_message_set_flags (msg, flags);
#else
  g_assert (gst_soup_vtable._soup_message_set_flags != NULL);
  gst_soup_vtable._soup_message_set_flags (msg, flags);
#endif
}

void
_soup_session_add_feature_by_type (SoupSession * session, GType feature_type)
{
#ifdef LINK_SOUP
  soup_session_add_feature_by_type (session, feature_type);
#else
  g_assert (gst_soup_vtable._soup_session_add_feature_by_type != NULL);
  gst_soup_vtable._soup_session_add_feature_by_type (session, feature_type);
#endif
}

SoupSessionFeature *
_soup_session_get_feature (SoupSession * session, GType feature_type)
{
#ifdef LINK_SOUP
  return soup_session_get_feature (session, feature_type);
#else
  g_assert (gst_soup_vtable._soup_session_get_feature != NULL);
  return gst_soup_vtable._soup_session_get_feature (session, feature_type);
#endif
}

void
_soup_message_headers_foreach (SoupMessageHeaders * hdrs,
    SoupMessageHeadersForeachFunc func, gpointer user_data)
{
#ifdef LINK_SOUP
  soup_message_headers_foreach (hdrs, func, user_data);
#else
  g_assert (gst_soup_vtable._soup_message_headers_foreach != NULL);
  gst_soup_vtable._soup_message_headers_foreach (hdrs, func, user_data);
#endif
}

SoupEncoding
_soup_message_headers_get_encoding (SoupMessageHeaders * hdrs)
{
#ifdef LINK_SOUP
  return soup_message_headers_get_encoding (hdrs);
#else
  g_assert (gst_soup_vtable._soup_message_headers_get_encoding != NULL);
  return gst_soup_vtable._soup_message_headers_get_encoding (hdrs);
#endif
}

goffset
_soup_message_headers_get_content_length (SoupMessageHeaders * hdrs)
{
#ifdef LINK_SOUP
  return soup_message_headers_get_content_length (hdrs);
#else
  g_assert (gst_soup_vtable._soup_message_headers_get_content_length != NULL);
  return gst_soup_vtable._soup_message_headers_get_content_length (hdrs);
#endif
}

SoupStatus
_soup_message_get_status (SoupMessage * msg)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  return msg->status_code;
#elif LINK_SOUP == 3
  return soup_message_get_status (msg);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_assert (gst_soup_vtable._soup_message_get_status_3 != NULL);
    return gst_soup_vtable._soup_message_get_status_3 (msg);
  } else {
    SoupMessage2 *msg2 = (SoupMessage2 *) msg;
    return msg2->status_code;
  }
#endif
}

const char *
_soup_message_get_reason_phrase (SoupMessage * msg)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  return msg->reason_phrase;
#elif LINK_SOUP == 3
  return soup_message_get_reason_phrase (msg);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_assert (gst_soup_vtable._soup_message_get_reason_phrase_3 != NULL);
    return gst_soup_vtable._soup_message_get_reason_phrase_3 (msg);
  } else {
    SoupMessage2 *msg2 = (SoupMessage2 *) msg;
    return msg2->reason_phrase;
  }
#endif
}

const char *
_soup_message_headers_get_one (SoupMessageHeaders * hdrs, const char *name)
{
#ifdef LINK_SOUP
  return soup_message_headers_get_one (hdrs, name);
#else
  g_assert (gst_soup_vtable._soup_message_headers_get_one != NULL);
  return gst_soup_vtable._soup_message_headers_get_one (hdrs, name);
#endif
}

void
_soup_message_disable_feature (SoupMessage * msg, GType feature_type)
{
#ifdef LINK_SOUP
  soup_message_disable_feature (msg, feature_type);
#else
  g_assert (gst_soup_vtable._soup_message_disable_feature != NULL);
  gst_soup_vtable._soup_message_disable_feature (msg, feature_type);
#endif
}

const char *
_soup_message_headers_get_content_type (SoupMessageHeaders * hdrs,
    GHashTable ** params)
{
#ifdef LINK_SOUP
  return soup_message_headers_get_content_type (hdrs, params);
#else
  g_assert (gst_soup_vtable._soup_message_headers_get_content_type != NULL);
  return gst_soup_vtable._soup_message_headers_get_content_type (hdrs, params);
#endif
}

gboolean
_soup_message_headers_get_content_range (SoupMessageHeaders * hdrs,
    goffset * start, goffset * end, goffset * total_length)
{
#ifdef LINK_SOUP
  return soup_message_headers_get_content_range (hdrs, start, end,
      total_length);
#else
  g_assert (gst_soup_vtable._soup_message_headers_get_content_range != NULL);
  return gst_soup_vtable._soup_message_headers_get_content_range (hdrs, start,
      end, total_length);
#endif
}

void
_soup_message_headers_set_range (SoupMessageHeaders * hdrs, goffset start,
    goffset end)
{
#ifdef LINK_SOUP
  soup_message_headers_set_range (hdrs, start, end);
#else
  g_assert (gst_soup_vtable._soup_message_headers_set_range != NULL);
  gst_soup_vtable._soup_message_headers_set_range (hdrs, start, end);
#endif
}

void
_soup_auth_authenticate (SoupAuth * auth, const char *username,
    const char *password)
{
#ifdef LINK_SOUP
  soup_auth_authenticate (auth, username, password);
#else
  g_assert (gst_soup_vtable._soup_auth_authenticate != NULL);
  gst_soup_vtable._soup_auth_authenticate (auth, username, password);
#endif
}

const char *
_soup_message_get_method (SoupMessage * msg)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  return msg->method;
#elif LINK_SOUP == 3
  return soup_message_get_method (msg);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_assert (gst_soup_vtable._soup_message_get_method_3 != NULL);
    return gst_soup_vtable._soup_message_get_method_3 (msg);
  } else {
    SoupMessage2 *msg2 = (SoupMessage2 *) msg;
    return msg2->method;
  }
#endif
}

void
_soup_session_send_async (SoupSession * session, SoupMessage * msg,
    GCancellable * cancellable, GAsyncReadyCallback callback,
    gpointer user_data)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  soup_session_send_async (session, msg, cancellable, callback, user_data);
#else
  soup_session_send_async (session, msg, G_PRIORITY_DEFAULT, cancellable,
      callback, user_data);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_assert (gst_soup_vtable._soup_session_send_async_3 != NULL);
    gst_soup_vtable._soup_session_send_async_3 (session, msg,
        G_PRIORITY_DEFAULT, cancellable, callback, user_data);
  } else {
    g_assert (gst_soup_vtable._soup_session_send_async_2 != NULL);
    gst_soup_vtable._soup_session_send_async_2 (session, msg,
        cancellable, callback, user_data);
  }
#endif
}

GInputStream *
_soup_session_send_finish (SoupSession * session,
    GAsyncResult * result, GError ** error)
{
#ifdef LINK_SOUP
  return soup_session_send_finish (session, result, error);
#else
  g_assert (gst_soup_vtable._soup_session_send_finish != NULL);
  return gst_soup_vtable._soup_session_send_finish (session, result, error);
#endif
}

GInputStream *
_soup_session_send (SoupSession * session, SoupMessage * msg,
    GCancellable * cancellable, GError ** error)
{
#ifdef LINK_SOUP
  return soup_session_send (session, msg, cancellable, error);
#else
  g_assert (gst_soup_vtable._soup_session_send != NULL);
  return gst_soup_vtable._soup_session_send (session, msg, cancellable, error);
#endif
}

void
gst_soup_session_cancel_message (SoupSession * session, SoupMessage * msg,
    GCancellable * cancellable)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 3
  g_cancellable_cancel (cancellable);
#else
  soup_session_cancel_message (session, msg, SOUP_STATUS_CANCELLED);
#endif
#else
  if (gst_soup_vtable.lib_version == 3) {
    g_cancellable_cancel (cancellable);
  } else {
    g_assert (gst_soup_vtable._soup_session_cancel_message_2 != NULL);
    gst_soup_vtable._soup_session_cancel_message_2 (session, msg,
        SOUP_STATUS_CANCELLED);
  }
#endif
}

SoupCookie *
_soup_cookie_parse (const char *header, const GstSoupUri * origin)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  return soup_cookie_parse (header, origin ? origin->soup_uri : NULL);
#else
  return soup_cookie_parse (header, origin ? origin->uri : NULL);
#endif
#else
  g_assert (gst_soup_vtable._soup_cookie_parse != NULL);

  if (origin == NULL)
    return gst_soup_vtable._soup_cookie_parse (header, NULL);

  if (gst_soup_vtable.lib_version == 2)
    return gst_soup_vtable._soup_cookie_parse (header, origin->soup_uri);

  /* libsoup 3 path */
#if GLIB_CHECK_VERSION(2, 66, 0)
  return gst_soup_vtable._soup_cookie_parse (header, origin->uri);
#else
  /* libsoup 3 requires GLib >= 2.69.1, unreachable with old GLib */
  g_assert_not_reached ();
  return NULL;
#endif
#endif
}

void
_soup_cookie_jar_add_cookie_full (SoupCookieJar * jar, SoupCookie * cookie,
    const GstSoupUri * origin)
{
#ifdef LINK_SOUP
#if LINK_SOUP == 2
  soup_cookie_jar_add_cookie_full (jar, cookie,
      origin ? origin->soup_uri : NULL, NULL);
#else
  soup_cookie_jar_add_cookie_full (jar, cookie, origin ? origin->uri : NULL,
      NULL);
#endif
#else
  g_assert (gst_soup_vtable._soup_cookie_jar_add_cookie_full != NULL);

  gpointer uri = NULL;
  if (origin != NULL) {
    if (gst_soup_vtable.lib_version == 2)
      uri = origin->soup_uri;
    else {
      /* libsoup 3 path */
#if GLIB_CHECK_VERSION(2, 66, 0)
      uri = origin->uri;
#else
      /* libsoup 3 requires GLib >= 2.69.1, unreachable with old GLib */
      g_assert_not_reached ();
#endif
    }
  }
  gst_soup_vtable._soup_cookie_jar_add_cookie_full (jar, cookie, uri, NULL);
#endif
}

void
_soup_cookie_free (SoupCookie * cookie)
{
#ifdef LINK_SOUP
  soup_cookie_free (cookie);
#else
  g_assert (gst_soup_vtable._soup_cookie_free != NULL);
  gst_soup_vtable._soup_cookie_free (cookie);
#endif
}

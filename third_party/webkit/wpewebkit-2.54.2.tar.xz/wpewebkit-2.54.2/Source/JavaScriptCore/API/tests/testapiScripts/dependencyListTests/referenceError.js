import "./foo.js";

tosehuas;
